import './App.css';
import {Component} from "react";
import LtiLogo from './Logo/logo'
import Menu  from "./Menu/menu";

//stateful component
export class App extends Component{

    constructor(props) {
        super(props);
        console.log("Inside Constructor");
        this.state={
            currentTime:new Date(),
            menu:[
                {
                menuId:1,
                name:"Industries"
            },
            {
                menuId:2,
                name:"Solutions"
            },
            {
                menuId:3,
                name:"Products"
            },
            {
                menuId:4,
                name:"AboutUs"
            }
        ]
        }
    }

    componentWillMount() {
        //super.componentWillMount();
        console.log("Enters Component will mount");
    }
    tick(){
        //changing the state
        this.setState({
            currentTime:new Date()
        })
    }

    componentDidMount() {
        //super.componentDidMount();
        console.log("Enters Component did mount");
        setInterval(()=>this.tick(),1000);
    
    }

    render() {
        return (
            <div>
                <figure>
                    <LtiLogo/>
                </figure>
        <h1>{this.state.currentTime.toLocaleTimeString()}</h1>
         <Menu menuItems={this.state.menu}/>       
            </div>
        )
    }
}

/*
function App() {
  return (
    <div className="App">
      <header >

      </header>
    </div>
  );
}

export default App;

 */
