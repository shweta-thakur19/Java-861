import { React } from 'react';



const Menu=(props)=>(
    <ul>
    {
    props.menuItems.map(item=>(
    <li>{item.name}</li>
))
    
}
</ul>
);

export default Menu;