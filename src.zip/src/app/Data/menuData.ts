import {MenuItem, SubMenuItem} from "../models/menuItem";


export let menuData:MenuItem[]=[new MenuItem('Category',[
  new SubMenuItem('Add','Category/CategoryAdd','pi pi-fw pi-plus'),
    new SubMenuItem('Edit','Category/CategoryEdit','pi pi-fw pi-pencil'),
    new SubMenuItem('ViewAll','Category/CategoryViewAll','pi pi-fw pi-inbox'),
    new SubMenuItem('View','Category/CategoryView','pi pi-fw pi-eye'),
    new SubMenuItem('Delete','Category/CategoryDelete','pi pi-fw pi-trash')
  ],
  'Category','pi pi-fw pi-briefcase'),
  new MenuItem('Product',[
      new SubMenuItem('Add','Product/ProductAdd','pi pi-fw pi-plus'),
      new SubMenuItem('Edit','Product/ProductEdit','pi pi-fw pi-pencil'),
      new SubMenuItem('ViewAll','Product/ProductViewAll','pi pi-fw pi-inbox'),
      new SubMenuItem('View','Product/ProductView','pi pi-fw pi-eye'),
      new SubMenuItem('Delete','Product/ProductDelete','pi pi-fw pi-trash')
    ],
    'Product','pi pi-fw pi-bars'),
  new MenuItem('Accounts',[],
    'Account','pi pi-fw pi-dollar'),
  new MenuItem('Shipping',[],
    'Shipping','pi pi-fw pi-shopping-cart')

];
