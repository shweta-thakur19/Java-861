import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductViewAllComponent } from './product-view-all.component';

describe('ProductViewAllComponent', () => {
  let component: ProductViewAllComponent;
  let fixture: ComponentFixture<ProductViewAllComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProductViewAllComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductViewAllComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
