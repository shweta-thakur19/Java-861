import { Injectable } from '@angular/core';
import {menuData} from "../Data/menuData";
import { MatSnackBar } from "@angular/material/snack-bar";
@Injectable({
  providedIn: 'root'
})
export class MenuService {

  constructor(private _snackBar:MatSnackBar) { }

  getMenuData():any
    {
      return menuData;
    }
  public openSnackBar(message:string,action:string){
    this._snackBar.open(message,action,{
      duration:3000,
    });
  }
}
