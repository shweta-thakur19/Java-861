import { Component, OnInit } from '@angular/core';
import { CategoryService } from 'src/app/services/category.service';

@Component({
  selector: 'app-category-view-all',
  templateUrl: './category-view-all.component.html',
  styleUrls: ['./category-view-all.component.css']
})
export class CategoryViewAllComponent implements OnInit {

  constructor(private categoryService:CategoryService) { }

  ngOnInit() {
    this.categoryService.getAllCatgories().subscribe(response=>{
      console.log(response);
    })
  }

}
